import argparse
import logging
import os
import random
import numpy as np
import torch
import torch.backends.cudnn as cudnn
from networks.swin_transformer import SwinTransNet, get_swin_tiny_config
from networks.vit_seg_modeling import VisionTransformer as ViT_seg
from networks.vit_seg_modeling import CONFIGS as CONFIGS_ViT_seg
from trainer import trainer_synapse 
from trainer_cataract import trainer_cataract1k # Assuming this works with Cataract1kDataset
from datasets.dataset_cataract import  Cataract1kDataset, RandomGenerator   # Import your dataset code

parser = argparse.ArgumentParser()
parser.add_argument('--root_path', type=str, default='../data/Cataract1k', help='root dir for data')
parser.add_argument('--dataset', type=str, default='Cataract1k', help='experiment_name')
parser.add_argument('--list_dir', type=str, default=None, help='list dir (not used for Cataract1k)')
parser.add_argument('--num_classes', type=int, default=3, help='output channel of network (background + Pupil + Cornea)')
parser.add_argument('--max_iterations', type=int, default=30000, help='maximum iteration number to train')
parser.add_argument('--max_epochs', type=int, default=150, help='maximum epoch number to train')
parser.add_argument('--batch_size', type=int, default=24, help='batch_size per gpu')
parser.add_argument('--n_gpu', type=int, default=1, help='total gpu')
parser.add_argument('--deterministic', type=int, default=1, help='whether use deterministic training')
parser.add_argument('--base_lr', type=float, default=0.01, help='segmentation network learning rate')
parser.add_argument('--img_size', type=int, default=224, help='input patch size of network input')
parser.add_argument('--seed', type=int, default=1234, help='random seed')
parser.add_argument('--n_skip', type=int, default=0, help='using number of skip-connect, default is 0 for Swin')
parser.add_argument('--model_name', type=str, default='Swin-Tiny', help='select model: Swin-Tiny or ViT variants')
parser.add_argument('--patch_size', type=int, default=4, help='patch size for Swin Transformer, default is 4')

args = parser.parse_args()

if __name__ == "__main__":
    if not args.deterministic:
        cudnn.benchmark = True
        cudnn.deterministic = False
    else:
        cudnn.benchmark = False
        cudnn.deterministic = True

    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    torch.cuda.manual_seed(args.seed)
    
    dataset_name = args.dataset
    dataset_config = {
        'Synapse': {
            'root_path': '../data/Synapse/train_npz',
            'list_dir': './lists/lists_Synapse',
            'num_classes': 9,
        },
        'Cataract1k': {
            'root_path': '/content/drive/MyDrive/CataractData/',
            'list_dir': None,  # Not needed for Cataract1k
            'num_classes': 3,  # Background (0), Pupil (1), Cornea (2)
        },
    }
    
    # Update args with dataset-specific config
    args.num_classes = dataset_config[dataset_name]['num_classes']
    args.root_path = dataset_config[dataset_name]['root_path']
    args.list_dir = dataset_config[dataset_name]['list_dir']
    args.is_pretrain = True
    args.exp = 'TU_' + dataset_name + str(args.img_size)
    snapshot_path = "../model/{}/{}".format(args.exp, 'TU')
    snapshot_path = snapshot_path + '_pretrain' if args.is_pretrain else snapshot_path
    snapshot_path += '_' + args.model_name
    snapshot_path = snapshot_path + '_skip' + str(args.n_skip)
    snapshot_path = snapshot_path + '_patch' + str(args.patch_size) if args.patch_size != 4 else snapshot_path
    snapshot_path = snapshot_path + '_' + str(args.max_iterations)[0:2] + 'k' if args.max_iterations != 30000 else snapshot_path
    snapshot_path = snapshot_path + '_epo' + str(args.max_epochs) if args.max_epochs != 30 else snapshot_path
    snapshot_path = snapshot_path + '_bs' + str(args.batch_size)
    snapshot_path = snapshot_path + '_lr' + str(args.base_lr) if args.base_lr != 0.01 else snapshot_path
    snapshot_path = snapshot_path + '_' + str(args.img_size)
    snapshot_path = snapshot_path + '_s' + str(args.seed) if args.seed != 1234 else snapshot_path

    if not os.path.exists(snapshot_path):
        os.makedirs(snapshot_path)

    # Model configuration
    if args.model_name.startswith('Swin'):
        config = get_swin_tiny_config()  # Call the function to get the ConfigDict
        config.patch_size = args.patch_size
    else:
        config = CONFIGS_ViT_seg[args.model_name]
        config.patches.grid = (int(args.img_size / args.patch_size), int(args.img_size / args.patch_size)) if args.model_name.find('R50') != -1 else None
    
    config.n_classes = args.num_classes
    config.n_skip = args.n_skip
    
    if args.model_name.startswith('Swin'):
        net = SwinTransNet(config, img_size=args.img_size, num_classes=config.n_classes).cuda()
    else:
        net = ViT_seg(config, img_size=args.img_size, num_classes=config.n_classes).cuda()
        net.load_from(weights=np.load(config.pretrained_path))

    # Custom data loading for Cataract1k (if trainer_synapse doesn't handle it)
    transform = RandomGenerator(output_size=[args.img_size, args.img_size])
    train_dataset = Cataract1kDataset(base_dir=args.root_path, split="train", transform=transform)
    val_dataset = Cataract1kDataset(base_dir=args.root_path, split="val", transform=None)
    args.train_loader = torch.utils.data.DataLoader(train_dataset, batch_size=args.batch_size, shuffle=True, num_workers=4)
    args.val_loader = torch.utils.data.DataLoader(val_dataset, batch_size=args.batch_size, shuffle=False, num_workers=4)

    # Call trainer
    trainer = {'Synapse': trainer_synapse, 'Cataract1k': trainer_cataract1k}  # Reuse trainer_synapse or define a new one
    trainer[dataset_name](args, net, snapshot_path)